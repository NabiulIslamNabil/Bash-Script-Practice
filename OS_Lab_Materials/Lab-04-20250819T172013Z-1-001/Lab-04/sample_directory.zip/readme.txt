ERROR: In a text file
